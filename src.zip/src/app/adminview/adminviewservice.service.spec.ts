import { TestBed, inject } from '@angular/core/testing';

import { AdminviewserviceService } from './adminviewservice.service';

describe('AdminviewserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminviewserviceService]
    });
  });

  it('should be created', inject([AdminviewserviceService], (service: AdminviewserviceService) => {
    expect(service).toBeTruthy();
  }));
});
