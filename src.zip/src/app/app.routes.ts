import { Routes, RouterModule } from '@angular/router';

import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminviewComponent } from './adminview/adminview.component';
import { LoginComponent } from './login/login.component';
import { ThankyoupageComponent } from './thankyoupage/thankyoupage.component';


export const routes: Routes = [
  { path: '',              component: LoginComponent },
 { path: 'adminview',      component: AdminviewComponent },
 { path: 'userform',       component: LoginComponent },
 { path: 'loginPage',       component: AdminloginComponent },
 { path: 'thankyoupage',       component: ThankyoupageComponent }

];

export const routing = RouterModule.forRoot(routes);