import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class AdminviewserviceService {
public userListUrl ;
  constructor(public http :Http) { }
	
	getuserListData(){
    let url: string = environment.searchApi;
	 let userListUrl = '/userList';
    return this.http.get(url+userListUrl).map(userlist => {
      return  userlist;
		//console.log("usersData = "+userlist)
    }, err => {
	console.log("err");
	});
  }

	
	downloaduserListData(){
		let url: string = environment.searchApi;
	url += '/download';
   return this.http.get(url,{responseType: ResponseContentType.Blob }).map(
    (res) => {
        return new Blob([res.blob()], { type: 'application/vnd.ms-excel' })
    })
		
	}
		
}
