import { Component, OnInit ,NgModule} from '@angular/core';
import {FormGroup, FormControl, FormBuilder, Validators, FormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import { UserFormService } from './user-form.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers : [UserFormService]
})
export class LoginComponent implements OnInit {
 userName : any;
 userrole : any;
 usercompany : any;
 usercontact : any;
 useremail : any;
 jsonData:any = {};
transactionData :any;
message = "";
//Create constructor
 constructor(private router: Router,private usersubmitservice : UserFormService,private toastr:ToastrService) {}

	ngOnInit() {
  }
	
	//call function to service	
	userformSubmit(){
		this.loaduserformData();
		
		if(this.userName == "" || this.userName == undefined){
			this.toastr.error('Please Enter Name');
			return false;
		}else if(this.userrole == "" || this.userrole == undefined){
				this.toastr.error('Please Enter Designation');
			return false;
		}else if(this.usercompany == "" || this.usercompany == undefined){
		this.toastr.error('Please Enter Company Name');
			return false;
		}else if(this.useremail == "" || this.useremail == undefined){
				this.toastr.error('Please Enter Your Email');
			return false;
		}else if(this.usercontact == "" || this.usercontact == undefined){
		this.toastr.error('Please Enter Your Contact No');
			return false;
		}
		
	   	 this.usersubmitservice.saveUser(this.jsonData)
          .subscribe(response => {
			 let res:any = response;
            this.transactionData = JSON.parse(res._body);
            this.message = this.transactionData.message;
                     
            this.router.navigate(['/thankyoupage']);
            setTimeout(() => { this.router.navigate(['/userform'] }, 6000); 
           
           this.resetForm();
                     }, error => {
           
			         this.toastr.error('Failed to save Data!', 'failed!');

          });
	}
		loaduserformData(){
			this.jsonData={};
 this.jsonData.delegatesName = this.userName;
this.jsonData.role=this.userrole;
this.jsonData.company=this.usercompany;
this.jsonData.email=this.useremail;
this.jsonData.contactNumber=this.usercontact;
}
			
loadLoginPage(){
	this.router.navigate(['/loginPage']);
}
	
	resetForm(){
		this.userName = '' ;
		this.userrole = '' ;
		this.usercompany = '' ;
		this.useremail = '' ;
		this.usercontact = '' ;
		
	}
	
	
		

}
