import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminviewComponent } from './adminview/adminview.component';
import {FormGroup, FormControl, FormBuilder, Validators, FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import {DataTableModule} from "angular-6-datatable";
import { routing } from './app.routes';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ThankyoupageComponent } from './thankyoupage/thankyoupage.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
	 AdminloginComponent,
	  AdminviewComponent,
	  ThankyoupageComponent
  ],
  imports: [
    BrowserModule,
	  FormsModule,
      routing,
	  HttpModule,
	  HttpClientModule,
      DataTableModule,
	  BrowserAnimationsModule,
	  ToastrModule.forRoot({
		timeOut: 1000,
        positionClass: 'toast-top-right',
        preventDuplicates: true,
        closeButton: true
	  })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
