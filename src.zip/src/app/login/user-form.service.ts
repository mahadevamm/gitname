import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class UserFormService {

  constructor(public http :Http){}

  public saveUser(jsonArray: any) {
	   let url: string = environment.searchApi;
      url += '/save';
    console.log('** insert clli-zone-lookup jsonData: ' + jsonArray);
    return this.http.post(url, jsonArray);
  }
}
