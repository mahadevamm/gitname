import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder} from '@angular/forms';
import { AdminloginService } from './adminlogin.service';
//import { MessageService } from '../../services/message.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css'],
  providers : [AdminloginService]
})
export class AdminloginComponent{
 firstname : any;
 password : any;
 jsonData:any;
//Create constructor
 constructor(private router: Router,private adminloginservice : AdminloginService,private toastr:ToastrService) {}
//call function to service	
smartLogin() {
        let username:any = this.firstname;
        let password:any = this.password;
	if(username == "" || username == undefined){
		this.toastr.error('Please Enter User Name');
		return false;
	}else if(password == "" || password == undefined){
					this.toastr.error('Please Enter password');
		return false;
	}
	    this.adminloginservice.getlogin(username,password).subscribe(response => {
		let res:any = response;
			console.log(res);
	    if (res._body == 'Login success') {
			        this.toastr.success('Logged in successfully!');

			this.router.navigate(['/adminview']);
            return false;
       }else{
		this.toastr.error('Invalid Login');
      }(err)=>{
			console.log(err)
		}
		})
}


}





