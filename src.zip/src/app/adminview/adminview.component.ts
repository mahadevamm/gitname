import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder} from '@angular/forms';
import { AdminviewserviceService } from './adminviewservice.service';
import {DataTableModule} from "angular-6-datatable";
import * as $ from "jquery";
import { ToastrService } from 'ngx-toastr';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-adminview',
  templateUrl: './adminview.component.html',
  styleUrls: ['./adminview.component.css'],
	providers : [AdminviewserviceService]
})
export class AdminviewComponent implements OnInit {
jsonData:any ;
//Create constructor
 constructor(private router: Router,private adminviewservice : AdminviewserviceService,private toastr:ToastrService) {}

  ngOnInit() {
	  this.getusersList();
  }
	getusersList(){
	this.adminviewservice.getuserListData().subscribe(response => {
		let res:any = response;
			console.log(res)
       this.jsonData = JSON.parse(res._body);

		$(function(){
                             //  $("#example").DataTable();
                              });
		
	   
      },(err)=>{
			console.log(err)
		})
	}
	
	logout(){
		this.router.navigate(['/userform']);
	}
	
	downloadReport(){
		this.adminviewservice.downloaduserListData().subscribe((res) => {      
           saveAs(res,'allInvoiceData.xls');
        });
	       	}

}
