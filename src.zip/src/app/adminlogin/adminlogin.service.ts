import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable()
export class AdminloginService {

  constructor(public http :Http){}

getlogin(userName,password)
  {
    let url: string = environment.searchApi;
	  url+= '/submit?userName='+userName+'&password='+password;
    return this.http.get(url).map(user => {
      return  user;
    }, err => {
	console.log("err");
	});
  }
		
}
